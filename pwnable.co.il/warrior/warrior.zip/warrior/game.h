#ifndef __GAME_H
#define __GAME_H


void game_loop();


#endif